
Hocam birde önermeden sonra modumu değiştir buttonuyla tam zıttını mesela mutluysa üzgün olacak şekilde bir button ekleyebilirsek
Birde hocam manuel bir şekilde dinleme şansımız olabilir mi



------------------------------------------------------

KNOWN BUGS 


CLIENT_ID = "7fb2bbe65a8145a6995b2ff519c63492"
CLIENT_SECRET = "61305c3b09fa42579be968dfdd8308da"